<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class ClashController extends Controller
{
    public function index(){
        $AUTH_KEY = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiIsImtpZCI6IjI4YTMxOGY3LTAwMDAtYTFlYi03ZmExLTJjNzQzM2M2Y2NhNSJ9.eyJpc3MiOiJzdXBlcmNlbGwiLCJhdWQiOiJzdXBlcmNlbGw6Z2FtZWFwaSIsImp0aSI6ImZmNWJkNjMzLThlYjEtNGVhMi1hYTc1LWIxZjhlZjMxNDhlNSIsImlhdCI6MTU5NzYxNjUzMiwic3ViIjoiZGV2ZWxvcGVyLzNiZTJkZDNkLTk1MjQtZGFjYS1iMWE3LTU4NjJlMjBmNDdjZSIsInNjb3BlcyI6WyJjbGFzaCJdLCJsaW1pdHMiOlt7InRpZXIiOiJkZXZlbG9wZXIvc2lsdmVyIiwidHlwZSI6InRocm90dGxpbmcifSx7ImNpZHJzIjpbIjc5LjMwLjM4LjIwNiJdLCJ0eXBlIjoiY2xpZW50In1dfQ.72qs-xFua4jxbzdyz16McVHjwbxEgRm-EF7PpCvmMRakMHBXaFSE3L6MNGXRa40Z5-i3tDT3pDXpjQ3LZ66naw";

        $response = Http::withToken($AUTH_KEY)->get("https://api.clashofclans.com/v1/clans/%239V2VJQ9P");

        $members = array();
        foreach ($response["memberList"] as $member){
            $members[] = $member["name"];
        }
        return view('welcome', ['members' => $members]);
    }

    public function extract(Request $request){
        $members = $request->members;
        $quantity = $request->number;
        $output = new \Symfony\Component\Console\Output\ConsoleOutput();
        $extracted = array();

        for($i = 0; $i < $quantity; $i++){
            do {
                $member = $members[array_rand($members)];
            } while(in_array($member, $extracted));

            $extracted[] = $member ;
        }
        return view('extracted', ['extracted' => $extracted]);
    }
}
