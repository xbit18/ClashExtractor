<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <link href="css/main.css" rel="stylesheet" type="text/css"/>

    </head>
    <body>
        <div class="flex-center position-ref full-height">

            <div class="content">
                <div class="title m-b-md">
                    War League Random Extractor
                </div>

                <div class="subtitle m-b-md">
                    Le medaglie vanno a...
                </div>

                <div class="">
                    <?php
                        $i = 0;
                    ?>
                    <?php $__currentLoopData = $extracted; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $i +=1;
                        ?>
                        <div class="input block"><?php echo e($i. ". ". $member); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <button class="submit padding-10 inline-block" onClick="window.location.reload();"><img src="/img/estraidinuovo.png" width=auto height="60" alt="submit" /> </button>

                <form class="inline-block" action="/">
                    <button type="submit" class="submit padding-10 inline-block"><img src="/img/tornaindietro.png" width=auto height="60" alt="submit" /></button>
                </form>
            </div>
        </div>
    </body>
</html>
<?php /**PATH E:\Desktop\Desktop\Progetti\EstrattoreClash\resources\views/extracted.blade.php ENDPATH**/ ?>